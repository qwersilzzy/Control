1) Download the Homeworks 2 Source file (64bit)
2) Extract it
1) Open Matlab and change directory to HW2_sources_Windows64bit/truetime (HW2_sources_Windows64bit is the one you just extracted)
2) Run init_trutime
3) Change directory back to HW2_sources_Windows64bit
4) Run addpath(genpath('.\jitterbug'))
5) Run inv_pend_three
6) Run the Simulink simulation (ctrl+T)












