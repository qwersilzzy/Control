%% PREPARE TWO TANK LAB
tankFcn.FreshClear;

%% START FOUR TANK LAB
lab = four_tank_app;